#include <stdio.h>
#include <windows.h>
#include <stdint.h>
#define NMAX 8000000000
int main(int argc, char *argv[]) {
    SetConsoleOutputCP(CP_UTF8);
    fflush(stdout);
    uint64_t n;
    long double suma;
    uint64_t i;
    do {
        printf("n: ");
        scanf("%lld", &n);
    } while ((n < 1) || (n > NMAX));
    suma = 0;
    for (i = n; i > 0; i--) {
        suma = suma + 1.0 / i;
    }
    printf("\nWersja 1\nSuma %lld wyrazów ciągu: %22.18Lf\n", n, suma);
    fflush(stdin);
    getchar();
    for (i = n, suma = 0; i; suma += 1. / i, i--);
    printf("\nWersja 2\nSuma %lld wyrazów ciągu: %22.18Lf\n", n, suma);
    fflush(stdin);
    getchar();
    for (i = 1, suma = 0; i <= n; suma += (double) 1 / i, i++);
    printf("\nWersja 3\nSuma %lld wyrazów ciągu: %22.18Lf\n", n, suma);
    fflush(stdin);
    getchar();
    return 0;
}