#include <stdio.h>
#include <string.h>
#include <windows.h>
#define SIZE 5
int main(int argc, char *argv[]) {
    SetConsoleOutputCP(CP_UTF8);
    fflush(stdout);
    const char name[] = "Jędrzej Gąsienica";
    int tabI[SIZE];
    float tabF[] = {1.1, 2.2, 3.3, 4.4, 5.5};
    printf("Demo A\n");
    puts(name); // wyprowadź łańcuch
    printf("\nDemo B\n");
    for (int i = 0; i < strlen(name); i++) {
        printf("%c", name[i]);
    }
    printf("\n\nDemo 1 - inicjowanie/wyprowadzenie w ciele pętli\n");
    for (int j = 0, i = 0; i < SIZE; i++) {
        tabI[i] = j++;
    }
    for (int i = 0; i < SIZE; i++) {
        printf("%4d", tabI[i]);
    }
    printf("\n\nDemo 2 - inicjowane/wyprowadzenie z instrukcją pustą \n");
    for (int j = 0, i = 0; i < SIZE; tabI[i++] = j++) {};
    for (int i = 0; i < SIZE; printf("%4d", tabI[i]), i++) {};
    printf("\n\nDemo 3\n");
    int length = sizeof(tabF) / sizeof(float);
    for (int i = 0; i < length; i++) {
        printf("%6.2f", tabF[i]);
    }
    printf("\n\nDemo 4\n");
    for (int i = 0; i < length; i++) {
        printf("tabF[%d]: ", i);
        scanf("%f", tabF + i);
    }
    printf("\nDemo 5\n");
    for (int i = 0; i < length; i++) {
        printf("%6.2f", tabF[i]);
    }
    printf("\n\nNaciśnij Enter, aby zakończyć...");
    fflush(stdin);
    getchar();
    return 0;
}