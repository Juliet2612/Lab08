#include <stdio.h>
#include <windows.h>
#include <conio.h>
#define ESC 0x1B
#define SP 0x20
#define ENT 0xD

int main(int argc, char *argv[]) {
SetConsoleOutputCP(CP_UTF8);
fflush(stdout);
int klawisz = 0;
while (1)
{
printf("\nNaciśnij jakiś klawisz (ESC->Koniec): ");
klawisz = getch();
if (klawisz == ESC)
{
fflush(stdout);
puts("\n");
break;
}
if ('a' <= klawisz && klawisz <= 'z')
printf("%c - mała litera.\n", klawisz);
else if ('A' <= klawisz && klawisz <= 'Z')
printf("%c - duża litera.\n", klawisz);
else if ('0' <= klawisz && klawisz <= '9')
printf("%c - cyfra.\n", klawisz);
else if (klawisz == ENT) {
fflush(stdout);
printf(" - klawisz enter.\n");;
} else if (klawisz == SP)
printf("%c - klawisz spacji.\n", klawisz);
else
printf(" - inny klawisz.\n");
}
fflush(stdout);
fflush(stdin);
printf("\nNaciśnij Enter, aby zakończyć...");
getchar();
return 0;
}