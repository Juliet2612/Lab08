#include <stdio.h>
#include <windows.h>
#include <math.h>

#define DELTA 0.000000000000000001
int main(int argc, char *argv[]) {
    SetConsoleOutputCP(CP_UTF8);
    fflush(stdout);
    long double a = 1.0, b = 1. / sqrt(2.0), t = .25, p = 1.0, y;
    puts("Liczba pi - algorytm Gaussa - Legendrea");
    printf("\na= %22.18Lf\nb= %22.18Lf\nt= %22.18Lf", a, b, t);
    printf("\npi=%22.18Lf\n", (a + b) * (a + b) / (4 * t));
    do {
        y = a;
        a = (a + b) / 2;
        b = sqrt(b * y);
        t = t - p * (y - a) * (y - a);
        p = 2 * p;
        printf("\na= %22.18Lf\nb= %22.18Lf\nt= %22.18Lf", a, b, t);
        printf("\npi=%22.18Lf\n", (a + b) * (a + b) / (4 * t));
    } while (fabsl(a - b) > DELTA);
    printf("\nPi= %.18f\n", M_PI);
    fflush(stdin);
    getchar();
    return 0;
}