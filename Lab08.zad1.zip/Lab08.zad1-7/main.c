#include <stdio.h>
#include <windows.h>
#define X 7
#define Y 13
int main(int argc, char *argv[]) {
    SetConsoleOutputCP(CP_UTF8);
    fflush(stdout);
    for (int raw = 0; raw < X; raw++) {
        for (char ch = 'A'; ch < ('A' + Y); ch++) {
            printf("%2c", ch);
        }
        printf("\n");
    }
    printf("\nNaciśnij eneter, aby zakończyć...");
    fflush(stdin);
    getchar();
    return 0;
}