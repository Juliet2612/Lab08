#include <stdio.h>
#include <windows.h>
#define N 5
int main(int argc, char *argv[]) {
    SetConsoleOutputCP(CP_UTF8);
    fflush(stdout);
    int i, n = 0, suma = 0;
    printf("Sumowanie %d liczb dodatnich\n\n", N);
    while (n < N) {
        printf("podaj i: ");
        scanf("%d", &i);
        if (i <= 0) continue;
        suma += i;
        n++;

    }
    printf("suma %d liczb dodatnich wynosi: %d\n\n", N, suma);
    printf("Naciśnij enter, aby zakończyć...");
    fflush(stdin);
    getchar();
    return 0;
}