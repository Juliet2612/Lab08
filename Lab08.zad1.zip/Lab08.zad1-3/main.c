#include <stdio.h>
#include <windows.h>
int main(int argc, char *argv[]) {
    SetConsoleOutputCP(CP_UTF8);
    fflush(stdout);
    int n, znak = -1;
    double x, suma = 1, xp, wyraz;
    do {
        printf("Podaj n: ");
        scanf("%d", &n);
    } while (n < 1);
    do {
        printf("Podaj x: ");
        scanf("%lf", &x);
    } while (x == 0.0);
    xp = 1;
    for (int i = 2; i <= n; i++) {
        xp *= x;
        wyraz = (double) i * xp * znak;
        suma += wyraz;
        znak *= -1;
    }
    printf("\nPodałeś n: %d, x: %.2lf", n, x);
    printf("\nSuma %d wyrazów ciągu: %.4lf\n\n", n, suma);
    fflush(stdin);
    getchar();
    return 0;
}