#include <stdio.h>
#include <stdbool.h>
#include <windows.h>
#include <conio.h>
int main(int argc, char *argv[]) {
    SetConsoleOutputCP(CP_UTF8);
    fflush(stdout);
    int n, i;
    bool result = false;
    char answer;
    do {
        do {
            printf("\n\nPodaj n (n>1): ");
            fflush(stdin);
            scanf("%d", &n);
        } while (n < 2);
        for (i = 2; i <= n / 2; i++) {
            if (result = n % i == 0) break;
        }
        if (result)
            printf("%d nie jest liczbą pierwszą, dzielnik: %d\n", n, i);
        else
            printf("%d jest liczbą pierwszą\n", n);
        fflush(stdin);
        printf("Kontynuować (t|T)? ");
        answer = getche();
    } while ((answer == 'T') || (answer == 't'));
    return 0;
}